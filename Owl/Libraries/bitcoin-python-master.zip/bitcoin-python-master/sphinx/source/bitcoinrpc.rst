:mod:`bitcoinrpc` --- Convenience functions
====================================================================================

.. automodule:: bitcoinrpc
   :members:
   :show-inheritance:
      
