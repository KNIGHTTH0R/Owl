==================================================
 bitcoin-python - Easy-to-use Bitcoin API client.
==================================================

``bitcoin-python`` is a set of Python libraries that allows easy access to the
bitcoin_ peer-to-peer cryptocurrency client API.

Contents:

.. toctree::
   :maxdepth: 2

   gettingstarted.rst
   apireference.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. _bitcoin: https://www.bitcoin.org/

