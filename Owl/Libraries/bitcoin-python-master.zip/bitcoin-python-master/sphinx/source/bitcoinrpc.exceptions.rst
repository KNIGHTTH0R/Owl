:mod:`bitcoinrpc.exceptions` --- Exception definitions
====================================================================================

.. automodule:: bitcoinrpc.exceptions
   :members:
   :show-inheritance:
      
