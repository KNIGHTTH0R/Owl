:mod:`bitcoinrpc.config` --- Utilities for reading bitcoin configuration files
====================================================================================

.. automodule:: bitcoinrpc.config
   :members:
   :show-inheritance:
   
